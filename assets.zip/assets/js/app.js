/* PROJECT GUIDE
 * File ini mengatur interaksi JavaScript sisi publik: navbar, dropdown,
 * indikator scroll, animasi, tombol kembali ke atas, dan komponen interaktif.
 * Untuk mengubah warna/ukuran font, utamakan assets/css/style.css atau
 * Admin > Tampilan; hindari menaruh style warna di JavaScript kecuali diperlukan.
 */
(() => {
    'use strict';

    const root = document.documentElement;
    const header = document.getElementById('siteHeader');
    const progress = document.getElementById('scrollProgress');
    const backTop = document.getElementById('backTop');
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    const navBackdrop = document.querySelector('.nav-backdrop');
    const indicator = document.querySelector('.nav-indicator');
    const dropdowns = document.querySelectorAll('.nav-dropdown');
    const desktopNav = window.matchMedia('(min-width: 1201px) and (hover: hover) and (pointer: fine)');

    const closeDropdown = (dropdown) => {
        dropdown.classList.remove('open');
        dropdown.querySelector(':scope > button')?.setAttribute('aria-expanded', 'false');
    };

    const closeAllDropdowns = () => dropdowns.forEach(closeDropdown);

    const setMobileNav = (open) => {
        nav?.classList.toggle('open', open);
        navToggle?.classList.toggle('active', open);
        navToggle?.setAttribute('aria-expanded', String(open));
        navToggle?.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
        navBackdrop?.classList.toggle('visible', open);
        document.body.classList.toggle('nav-drawer-open', open);
        if (!open) closeAllDropdowns();
    };

    navToggle?.addEventListener('click', () => {
        setMobileNav(!(nav?.classList.contains('open') ?? false));
    });

    navBackdrop?.addEventListener('click', () => setMobileNav(false));

    dropdowns.forEach((dropdown) => {
        const button = dropdown.querySelector(':scope > button');

        button?.addEventListener('click', (event) => {
            event.stopPropagation();
            if (desktopNav.matches) {
                const isOpen = dropdown.classList.contains('open');
                closeAllDropdowns();
                if (!isOpen) {
                    dropdown.classList.add('open');
                    button.setAttribute('aria-expanded', 'true');
                }
                return;
            }

            const isOpen = dropdown.classList.contains('open');
            closeAllDropdowns();
            if (!isOpen) {
                dropdown.classList.add('open');
                button.setAttribute('aria-expanded', 'true');
            }
        });

        dropdown.addEventListener('pointerenter', () => {
            if (!desktopNav.matches) return;
            closeAllDropdowns();
            dropdown.classList.add('open');
            button?.setAttribute('aria-expanded', 'true');
        });

        dropdown.addEventListener('pointerleave', () => {
            if (!desktopNav.matches) return;
            if (!dropdown.contains(document.activeElement)) closeDropdown(dropdown);
        });

        dropdown.addEventListener('focusout', (event) => {
            if (!dropdown.contains(event.relatedTarget) && desktopNav.matches) {
                closeDropdown(dropdown);
            }
        });

        dropdown.querySelectorAll('.dropdown-menu a').forEach((link) => {
            link.addEventListener('click', () => {
                closeDropdown(dropdown);
                if (!desktopNav.matches) setMobileNav(false);
            });
        });
    });

    document.addEventListener('click', (event) => {
        if (!(event.target instanceof Element)) return;
        if (!event.target.closest('.nav-dropdown')) closeAllDropdowns();
        if (!event.target.closest('.nav-shell') && nav?.classList.contains('open')) {
            setMobileNav(false);
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeAllDropdowns();
            if (nav?.classList.contains('open')) {
                setMobileNav(false);
                navToggle?.focus();
            }
        }
    });

    const closeDrawerOnDesktop = () => {
        if (window.matchMedia('(min-width: 1201px)').matches) setMobileNav(false);
    };
    window.addEventListener('resize', closeDrawerOnDesktop, { passive: true });

    const moveIndicator = () => {
        if (!indicator || !nav) {
            return;
        }

        const active = nav.querySelector(':scope > a.active, :scope > .nav-dropdown.active > .nav-dropdown-trigger');

        if (!active) {
            indicator.style.opacity = '0';
            return;
        }

        const navRect = nav.getBoundingClientRect();
        const activeRect = active.getBoundingClientRect();

        indicator.style.left = `${activeRect.left - navRect.left}px`;
        indicator.style.width = `${activeRect.width}px`;
        indicator.style.opacity = '1';
    };

    const updateScrollState = () => {
        const scrollTop = window.scrollY;
        const documentHeight =
            document.documentElement.scrollHeight - window.innerHeight;

        header?.classList.toggle('scrolled', scrollTop > 30);

        if (progress) {
            const percentage = documentHeight > 0
                ? (scrollTop / documentHeight) * 100
                : 0;

            progress.style.width = `${percentage}%`;
        }

        backTop?.classList.toggle('show', scrollTop > 500);
    };

    window.addEventListener(
        'scroll',
        updateScrollState,
        { passive: true }
    );

    window.addEventListener(
        'resize',
        moveIndicator
    );

    window.addEventListener(
        'load',
        moveIndicator
    );

    updateScrollState();

    setTimeout(moveIndicator, 150);

    backTop?.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth',
        });
    });

    document.querySelectorAll('a[href^="#"]').forEach((link) => {
        link.addEventListener('click', (event) => {
            const selector = link.getAttribute('href');

            if (!selector || selector === '#') {
                return;
            }

            const target = document.querySelector(selector);

            if (!target) {
                return;
            }

            event.preventDefault();
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start',
            });
        });
    });

    const revealObserver = new IntersectionObserver(
        (entries, observer) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) {
                    return;
                }

                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            });
        },
        {
            threshold: 0.12,
        }
    );

    document.querySelectorAll('.reveal').forEach((element) => {
        revealObserver.observe(element);
    });

    // Location section: copy the canonical address with clear, accessible feedback.
    document.querySelectorAll('[data-copy-address]').forEach((button) => {
        button.addEventListener('click', async () => {
            const address = button.getAttribute('data-copy-address') || '';
            const label = button.querySelector('[data-copy-label]');
            const originalLabel = label?.textContent || 'Salin Alamat';
            try {
                if (navigator.clipboard && window.isSecureContext) {
                    await navigator.clipboard.writeText(address);
                } else {
                    const field = document.createElement('textarea');
                    field.value = address;
                    field.setAttribute('readonly', '');
                    field.style.position = 'fixed';
                    field.style.opacity = '0';
                    document.body.appendChild(field);
                    field.select();
                    const copied = document.execCommand('copy');
                    field.remove();
                    if (!copied) throw new Error('Clipboard unavailable');
                }
                if (label) label.textContent = 'Alamat Tersalin';
                button.classList.add('is-copied');
                button.setAttribute('aria-label', 'Alamat berhasil disalin');
                window.setTimeout(() => {
                    if (label) label.textContent = originalLabel;
                    button.classList.remove('is-copied');
                    button.setAttribute('aria-label', originalLabel);
                }, 2200);
            } catch (error) {
                if (label) label.textContent = 'Salin gagal';
                window.setTimeout(() => { if (label) label.textContent = originalLabel; }, 2200);
            }
        });
    });

    document.querySelectorAll('[data-counter]').forEach((element) => {
        const counterObserver = new IntersectionObserver(
            (entries, observer) => {
                if (!entries[0].isIntersecting) {
                    return;
                }

                const target = Number(element.dataset.counter) || 0;
                const suffix = element.dataset.suffix || '';
                let current = 0;

                const animate = () => {
                    current = Math.min(
                        target,
                        current + Math.max(1, Math.ceil(target / 40))
                    );

                    element.textContent = `${current}${suffix}`;

                    if (current < target) {
                        requestAnimationFrame(animate);
                    }
                };

                animate();
                observer.disconnect();
            },
            {
                threshold: 0.6,
            }
        );

        counterObserver.observe(element);
    });
})();

/* Page transition and button micro-interactions */
window.addEventListener('pageshow', () => {
    // Clear a stale leaving state when returning through browser history/BFCache.
    document.body.classList.remove('page-leaving');
    document.body.classList.add('page-ready');
});

document.querySelectorAll('a:not([target="_blank"]):not([href^="#"]):not([href^="mailto:"]):not([href^="tel:"])').forEach((link) => {
    link.addEventListener('click', (event) => {
        const href = link.getAttribute('href');

        if (!href || href.startsWith('javascript:') || link.hasAttribute('download')) {
            return;
        }

        if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
            return;
        }

        let destination;
        try {
            destination = new URL(href, window.location.href);
        } catch (_) {
            return;
        }

        // Leave file downloads and known download endpoints to the browser; they
        // do not navigate to a new document, so an overlay would otherwise linger.
        if (/\.(pdf|zip|png|jpe?g|webp|svg|docx?|xlsx?|pptx?)(?:$)/i.test(destination.pathname) ||
            /(?:^|\/)download-ppdb\.php$/i.test(destination.pathname)) {
            return;
        }

        // Keep external navigation native; only animate same-origin page changes.
        if (destination.origin !== window.location.origin) {
            return;
        }

        // Same-page anchor navigation should never trigger the page overlay.
        if (destination.pathname === window.location.pathname &&
            destination.search === window.location.search && destination.hash) {
            return;
        }

        if (document.body.classList.contains('page-leaving')) {
            event.preventDefault();
            return;
        }

        event.preventDefault();
        document.body.classList.remove('page-ready');
        document.body.classList.add('page-leaving');

        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        window.setTimeout(() => {
            window.location.assign(destination.href);
        }, reducedMotion ? 0 : 300);
    });
});

/* =========================================================
   TEACHER PROFILE MODAL
   ========================================================= */
(() => {
    const modal = document.getElementById('teacherModal');

    if (!modal) {
        return;
    }

    const image = document.getElementById('teacherModalImage');
    const name = document.getElementById('teacherModalName');
    const position = document.getElementById('teacherModalPosition');
    const positionFact = document.getElementById('teacherModalPositionFact');
    const education = document.getElementById('teacherModalEducation');
    const subject = document.getElementById('teacherModalSubject');
    const bio = document.getElementById('teacherModalBio');
    const cards = document.querySelectorAll('[data-teacher-modal]');
    const closeButtons = modal.querySelectorAll('[data-teacher-close]');

    let lastTrigger = null;

    const openModal = (card) => {
        lastTrigger = card;

        if (image) {
            image.src = card.dataset.image || '';
            image.alt = card.dataset.name || 'Guru';
        }

        if (name) {
            name.textContent = card.dataset.name || 'Nama Guru';
        }

        if (position) {
            position.textContent = card.dataset.position || 'TENAGA PENDIDIK';
        }

        if (positionFact) {
            positionFact.textContent = card.dataset.position || 'Tenaga Pendidik';
        }

        if (education) {
            education.textContent = card.dataset.education || 'S1';
        }

        if (subject) {
            subject.textContent = card.dataset.subject || 'Belum diisi';
        }

        if (bio) {
            bio.textContent = card.dataset.bio || 'Profil guru belum dilengkapi.';
        }

        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('teacher-modal-open');

        window.setTimeout(() => {
            modal.querySelector('.teacher-modal-close')?.focus();
        }, 100);
    };

    const closeModal = () => {
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('teacher-modal-open');

        window.setTimeout(() => {
            if (lastTrigger instanceof HTMLElement) {
                lastTrigger.focus();
            }
        }, 420);
    };

    cards.forEach((card) => {
        card.addEventListener('click', () => openModal(card));
    });

    closeButtons.forEach((button) => {
        button.addEventListener('click', closeModal);
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal.classList.contains('is-open')) {
            closeModal();
        }
    });
})();

/* Homepage YouTube story modal */
(() => {
    const modal = document.getElementById('homeVideoModal');
    const frame = document.getElementById('homeVideoFrame');
    const title = document.getElementById('homeVideoTitle');

    if (!modal || !frame) return;

    const close = () => {
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('video-modal-open');
        frame.innerHTML = '';
    };

    document.querySelectorAll('[data-video-id]').forEach((card) => {
        card.addEventListener('click', () => {
            const id = card.dataset.videoId;
            if (!id) return;

            title.textContent = card.dataset.videoTitle || 'Cerita Sekolah';
            frame.innerHTML = `<iframe src="https://www.youtube.com/embed/${encodeURIComponent(id)}?autoplay=1&rel=0" title="${(card.dataset.videoTitle || 'Cerita Sekolah').replace(/"/g, '&quot;')}" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
            modal.classList.add('is-open');
            modal.setAttribute('aria-hidden', 'false');
            document.body.classList.add('video-modal-open');
        });
    });

    modal.querySelectorAll('[data-video-close]').forEach((element) => {
        element.addEventListener('click', close);
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal.classList.contains('is-open')) {
            close();
        }
    });
})();

/* =========================================================
   PROFILE PAGE — PARALLAX / MOTION DETAILS
   ========================================================= */
(() => {
    const hero = document.querySelector('.profile-hero');
    const media = document.querySelector('[data-profile-parallax]');

    if (!hero || !media) {
        return;
    }

    let ticking = false;

    const updateParallax = () => {
        const rect = hero.getBoundingClientRect();
        const progress = Math.max(0, Math.min(1, -rect.top / Math.max(1, hero.offsetHeight)));
        media.style.transform = `translate3d(0, ${progress * 7}%, 0) scale(${1.04 + progress * .025})`;
        ticking = false;
    };

    window.addEventListener('scroll', () => {
        if (!ticking) {
            requestAnimationFrame(updateParallax);
            ticking = true;
        }
    }, { passive: true });

    updateParallax();
})();

(() => {
    const profileItems = document.querySelectorAll('.profile-timeline-item, .profile-identity-item, .profile-major-card, .profile-facility-card');

    if (!profileItems.length || !('IntersectionObserver' in window)) {
        return;
    }

    const observer = new IntersectionObserver((entries, instance) => {
        entries.forEach((entry) => {
            if (!entry.isIntersecting) {
                return;
            }

            entry.target.classList.add('is-visible');
            instance.unobserve(entry.target);
        });
    }, { threshold: .12 });

    profileItems.forEach((item) => observer.observe(item));
})();

/* =========================================================
   GURU & STAFF interactions
   ========================================================= */
(() => {
    'use strict';

    const people = [...document.querySelectorAll('.guru-person-card[data-person]')];
    const principalHero = document.querySelector('.guru-editorial-hero');
    const search = document.getElementById('guruSearch');
    const empty = document.getElementById('guruEmpty');
    const modal = document.getElementById('guruModal');
    if (!people.length || !modal) return;

    const modalPanel = modal.querySelector('.guru-modal-panel');
    const modalPhoto = document.getElementById('guruModalPhoto');
    const modalName = document.getElementById('guruModalName');
    const modalPosition = document.getElementById('guruModalPosition');
    const modalField = document.getElementById('guruModalField');
    const modalEducation = document.getElementById('guruModalEducation');
    const modalFieldDetail = document.getElementById('guruModalFieldDetail');
    const modalDescription = document.getElementById('guruModalDescription');
    let previousFocus = null;

    const getPerson = (card) => {
        try { return JSON.parse(card.dataset.person || '{}'); }
        catch { return {}; }
    };

    const resolveImage = (person) => {
        const value = String(person.fallback_image || '').trim();
        if (!value) return '';
        if (/^(https?:)?\/\//i.test(value) || value.startsWith('data:')) return value;
        return value;
    };

    const openModal = (card) => {
        const person = getPerson(card);
        previousFocus = document.activeElement;
        modalPhoto.src = resolveImage(person);
        modalPhoto.alt = person.name || 'Foto personel';
        modalName.textContent = person.name || 'Profil personel';
        modalPosition.textContent = person.position || 'Tenaga Kependidikan';
        modalField.textContent = person.field || person.position || 'SMK INFOKOM';
        modalEducation.textContent = person.education || 'Data belum tersedia';
        modalFieldDetail.textContent = person.subject || person.field || 'Data belum tersedia';
        modalDescription.textContent = person.bio || 'Informasi tambahan belum tersedia.';
        modal.classList.add('open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        window.setTimeout(() => modalPanel?.focus(), 30);
    };

    const closeModal = () => {
        modal.classList.remove('open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        if (previousFocus instanceof HTMLElement) previousFocus.focus();
    };

    people.forEach((card) => {
        card.querySelector('.guru-view')?.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            openModal(card);
        });
    });
    document.querySelectorAll('[data-close-guru]').forEach((element) => element.addEventListener('click', closeModal));
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal.classList.contains('open')) closeModal();
    });

    const applySearch = () => {
        const query = String(search?.value || '').trim().toLocaleLowerCase('id');
        const principalMatches = !query || String(principalHero?.dataset.principalName || '').includes(query);
        let visible = 0;
        people.forEach((card) => {
            const text = `${card.dataset.name || ''} ${card.textContent || ''}`.toLocaleLowerCase('id');
            const show = !query || text.includes(query);
            card.classList.toggle('is-hidden', !show);
            if (show) {
                visible += 1;
                card.classList.remove('is-visible');
                requestAnimationFrame(() => card.classList.add('is-visible'));
            }
        });
        document.querySelectorAll('.guru-person-group').forEach((group) => {
            const cards = [...group.querySelectorAll('.guru-person-card')];
            group.hidden = cards.length === 0 || cards.every((card) => card.classList.contains('is-hidden'));
        });
        if (empty) empty.hidden = visible !== 0 || principalMatches;
    };
    search?.addEventListener('input', applySearch);
})();

/* =========================================================
   INFORMASI / YOUTUBE ONLY INTERACTIONS
   ========================================================= */
(() => {
    const grid = document.getElementById('infoVideoGrid');
    const search = document.getElementById('infoVideoSearch');
    const empty = document.getElementById('infoVideoEmpty');
    const reset = document.getElementById('infoResetSearch');
    const filters = document.querySelectorAll('[data-info-filter]');
    const modal = document.getElementById('homeVideoModal');
    const frame = document.getElementById('homeVideoFrame');
    const title = document.getElementById('homeVideoTitle');
    const description = document.getElementById('homeVideoDescription');

    if (!grid) return;

    let activeFilter = 'all';

    const escapeHtml = (value) => String(value || '').replace(/[&<>'"]/g, (char) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#039;',
        '"': '&quot;'
    })[char]);

    const openVideo = (button) => {
        if (!modal || !frame) return;
        const id = button.dataset.videoId || '';
        if (!id) return;

        const videoTitle = button.dataset.videoTitle || 'Video sekolah';
        const videoDescription = button.dataset.videoDescription || '';
        title.textContent = videoTitle;
        description.textContent = videoDescription;
        frame.innerHTML = `<iframe src="https://www.youtube.com/embed/${encodeURIComponent(id)}?autoplay=1&rel=0" title="${escapeHtml(videoTitle)}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>`;
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('video-modal-open');
    };

    const closeVideo = () => {
        if (!modal) return;
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('video-modal-open');
        if (frame) frame.innerHTML = '';
    };

    grid.querySelectorAll('.info-video-trigger').forEach((button) => {
        button.addEventListener('click', () => openVideo(button));
    });

    modal?.querySelectorAll('[data-video-close]').forEach((element) => {
        element.addEventListener('click', closeVideo);
    });

    const applyFilter = () => {
        const query = (search?.value || '').trim().toLowerCase();
        let visible = 0;

        grid.querySelectorAll('[data-info-card]').forEach((card) => {
            const category = card.dataset.category || '';
            const text = card.dataset.title || '';
            const matchCategory = activeFilter === 'all' || category === activeFilter;
            const matchSearch = !query || text.includes(query);
            const show = matchCategory && matchSearch;

            card.classList.toggle('is-filter-hidden', !show);
            if (show) {
                visible += 1;
                card.style.setProperty('--info-delay', `${Math.min(visible - 1, 5) * 70}ms`);
                card.classList.remove('is-visible');
                requestAnimationFrame(() => card.classList.add('is-visible'));
            }
        });

        if (empty) empty.hidden = visible !== 0;
    };

    search?.addEventListener('input', applyFilter);

    filters.forEach((filter) => {
        filter.addEventListener('click', () => {
            filters.forEach((item) => item.classList.remove('active'));
            filter.classList.add('active');
            activeFilter = filter.dataset.infoFilter || 'all';
            applyFilter();
        });
    });

    reset?.addEventListener('click', () => {
        if (search) search.value = '';
        activeFilter = 'all';
        filters.forEach((item) => item.classList.toggle('active', item.dataset.infoFilter === 'all'));
        applyFilter();
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal?.classList.contains('is-open')) {
            closeVideo();
        }
    });
})();

/* Facility showcase interactions */
(() => {
    const grid = document.querySelector('#facilityGrid');
    const modal = document.querySelector('#facilityModal');
    if (!grid && !modal) return;

    const cards = [...document.querySelectorAll('[data-facility-card]')];
    const filters = [...document.querySelectorAll('[data-facility-filter]')];
    const image = document.querySelector('#facilityModalImage');
    const count = document.querySelector('#facilityModalCount');
    const title = document.querySelector('#facilityModalTitle');
    const category = document.querySelector('#facilityModalCategory');
    const description = document.querySelector('#facilityModalDescription');
    const location = document.querySelector('#facilityModalLocation');
    const capacity = document.querySelector('#facilityModalCapacity');
    const prev = document.querySelector('#facilityPrev');
    const next = document.querySelector('#facilityNext');
    let gallery = [];
    let galleryIndex = 0;

    const showImage = () => {
        if (!image || !gallery.length) return;
        image.style.opacity = '0';
        window.setTimeout(() => {
            image.src = gallery[galleryIndex];
            image.onload = () => { image.style.opacity = '1'; };
            if (count) count.textContent = String(galleryIndex + 1).padStart(2, '0') + ' / ' + String(gallery.length).padStart(2, '0');
        }, 120);
    };

    const openModal = (payload) => {
        if (!modal) return;
        gallery = [payload.image, ...(payload.gallery || [])].filter(Boolean);
        galleryIndex = 0;
        if (title) title.textContent = payload.name || '';
        if (category) category.textContent = (payload.category || 'FASILITAS') + ' / DETAIL';
        if (description) description.textContent = payload.description || 'Detail fasilitas sekolah.';
        if (location) location.textContent = payload.location || '—';
        if (capacity) capacity.textContent = payload.capacity || '—';
        showImage();
        modal.classList.add('open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('modal-open');
    };

    const closeModal = () => {
        if (!modal) return;
        modal.classList.remove('open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('modal-open');
        window.setTimeout(() => { if (image) image.src = ''; }, 350);
    };

    document.querySelectorAll('[data-facility-open]').forEach((button) => {
        button.addEventListener('click', () => {
            try { openModal(JSON.parse(button.dataset.facilityOpen)); }
            catch (_) { /* ignore malformed payload */ }
        });
    });
    document.querySelectorAll('[data-facility-close]').forEach((el) => el.addEventListener('click', closeModal));
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && modal?.classList.contains('open')) closeModal(); });
    prev?.addEventListener('click', () => { if (gallery.length > 1) { galleryIndex = (galleryIndex - 1 + gallery.length) % gallery.length; showImage(); } });
    next?.addEventListener('click', () => { if (gallery.length > 1) { galleryIndex = (galleryIndex + 1) % gallery.length; showImage(); } });

    filters.forEach((filter) => {
        filter.addEventListener('click', () => {
            filters.forEach((item) => item.classList.remove('active'));
            filter.classList.add('active');
            const target = filter.dataset.facilityFilter;
            cards.forEach((card, index) => {
                const match = target === 'all' || card.dataset.category === target;
                card.classList.toggle('is-hidden', !match);
                if (match) {
                    card.style.setProperty('--facility-delay', `${Math.min(index, 6) * 70}ms`);
                    window.requestAnimationFrame(() => card.classList.add('is-visible'));
                }
            });
        });
    });
})();

/* BKK career portal interactions */
(function () {
    const page = document.querySelector('.bkk-page');
    if (!page) return;
    const search = document.getElementById('bkkJobSearch');
    const cards = Array.from(document.querySelectorAll('[data-job-card]'));
    const filters = Array.from(document.querySelectorAll('[data-job-filter]'));
    const empty = document.getElementById('bkkJobEmpty');
    let activeFilter = 'all';
    function filterJobs() {
        const query = (search?.value || '').trim().toLowerCase();
        let visible = 0;
        cards.forEach((card) => {
            const category = card.dataset.category || '';
            const text = card.dataset.search || '';
            const show = (activeFilter === 'all' || category === activeFilter) && (!query || text.includes(query));
            card.classList.toggle('is-hidden', !show);
            if (show) visible += 1;
        });
        if (empty) empty.hidden = visible !== 0;
    }
    filters.forEach((button) => button.addEventListener('click', () => {
        activeFilter = button.dataset.jobFilter || 'all';
        filters.forEach((item) => item.classList.toggle('is-active', item === button));
        filterJobs();
    }));
    search?.addEventListener('input', filterJobs);
    const modal = document.getElementById('bkkJobModal');
    const title = document.getElementById('bkkModalTitle');
    const company = document.getElementById('bkkModalCompany');
    const category = document.getElementById('bkkModalCategory');
    const location = document.getElementById('bkkModalLocation');
    const deadline = document.getElementById('bkkModalDeadline');
    const description = document.getElementById('bkkModalDescription');
    const apply = document.getElementById('bkkModalApply');
    function closeModal() {
        if (!modal) return;
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('modal-open');
    }
    function openModal(card) {
        if (!modal) return;
        let job = {};
        try { job = JSON.parse(card.dataset.job || '{}'); } catch (error) { return; }
        title.textContent = job.position || 'Lowongan';
        company.textContent = job.company || '';
        category.textContent = job.category || 'LOWONGAN';
        location.textContent = job.location || 'Lokasi belum ditentukan';
        deadline.textContent = `Deadline: ${job.deadline || 'Terbuka'}`;
        description.textContent = job.description || 'Deskripsi lowongan belum tersedia.';
        if (job.apply_url) { apply.href = job.apply_url; apply.style.display = 'inline-flex'; }
        else { apply.removeAttribute('href'); apply.style.display = 'none'; }
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('modal-open');
    }
    document.querySelectorAll('[data-job-open]').forEach((button) => button.addEventListener('click', () => {
        const card = button.closest('[data-job-card]');
        if (card) openModal(card);
    }));
    document.querySelectorAll('[data-job-close]').forEach((element) => element.addEventListener('click', closeModal));
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeModal(); });
})();

/* ==========================================================
   PKL INTERACTION LAYER
   ========================================================== */
(function () {
    'use strict';

    const page = document.querySelector('.pkl-page');
    if (!page) return;

    const reveals = page.querySelectorAll('.reveal');
    const revealObserver = 'IntersectionObserver' in window
        ? new IntersectionObserver((entries, observer) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) return;
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            });
        }, { threshold: 0.12 })
        : null;

    if (revealObserver) {
        reveals.forEach((item) => revealObserver.observe(item));
    } else {
        reveals.forEach((item) => item.classList.add('is-visible'));
    }

    const timeline = page.querySelector('[data-pkl-timeline]');
    const progress = page.querySelector('.pkl-timeline-progress');
    const phases = [...page.querySelectorAll('[data-phase]')];

    function updateTimeline() {
        if (!timeline || !progress) return;

        const rect = timeline.getBoundingClientRect();
        const viewport = window.innerHeight;
        const total = Math.max(1, rect.height - viewport * 0.34);
        const passed = Math.min(Math.max((viewport * 0.58 - rect.top) / total, 0), 1);

        if (window.innerWidth <= 1100) {
            progress.style.height = `${passed * 100}%`;
            progress.style.width = '100%';
        } else {
            progress.style.width = `${passed * 100}%`;
        }

        phases.forEach((phase, index) => {
            const phaseRect = phase.getBoundingClientRect();
            const active = phaseRect.top < viewport * 0.68 && phaseRect.bottom > viewport * 0.25;
            phase.classList.toggle('is-active', active);
        });
    }

    let ticking = false;
    function onScroll() {
        if (ticking) return;
        ticking = true;
        requestAnimationFrame(() => {
            updateTimeline();
            ticking = false;
        });
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', updateTimeline);
    updateTimeline();

    const filters = page.querySelectorAll('[data-pkl-filter]');
    const items = page.querySelectorAll('[data-pkl-item]');

    filters.forEach((filter) => {
        filter.addEventListener('click', () => {
            filters.forEach((button) => button.classList.remove('is-active'));
            filter.classList.add('is-active');

            const value = filter.dataset.pklFilter;
            items.forEach((item) => {
                const content = (item.dataset.pklCategory || '').toLowerCase();
                const visible = value === 'all' || content.includes(value);
                item.classList.toggle('is-hidden', !visible);
            });
        });
    });

    const hero = page.querySelector('.pkl-hero');
    const visual = page.querySelector('.pkl-hero-visual');

    if (hero && visual && window.matchMedia('(pointer:fine)').matches) {
        hero.addEventListener('pointermove', (event) => {
            const rect = hero.getBoundingClientRect();
            const x = (event.clientX - rect.left) / rect.width - 0.5;
            const y = (event.clientY - rect.top) / rect.height - 0.5;
            visual.style.transform = `translate3d(${x * 8}px, ${y * 8}px, 0)`;
        });

        hero.addEventListener('pointerleave', () => {
            visual.style.transform = '';
        });
    }
})();

/* Achievement / Prestasi interactions */
(() => {
    const page = document.querySelector('.achievement-page');
    if (!page) return;

    const filters = [...page.querySelectorAll('[data-achievement-filter]')];
    const items = [...page.querySelectorAll('[data-achievement-item]')];

    filters.forEach((filter) => {
        filter.addEventListener('click', () => {
            const value = filter.dataset.achievementFilter || 'all';
            filters.forEach((button) => button.classList.toggle('is-active', button === filter));

            items.forEach((item) => {
                const major = item.dataset.achievementMajor || '';
                const visible = value === 'all' || major === value;
                item.classList.toggle('is-hidden', !visible);
            });
        });
    });

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const trophy = page.querySelector('.achievement-trophy-stage');

    if (trophy && !reduceMotion && window.matchMedia('(pointer:fine)').matches) {
        const hero = page.querySelector('.achievement-hero');
        hero?.addEventListener('pointermove', (event) => {
            const rect = hero.getBoundingClientRect();
            const x = (event.clientX - rect.left) / rect.width - 0.5;
            const y = (event.clientY - rect.top) / rect.height - 0.5;
            trophy.style.transform = `translate3d(${x * 10}px, ${y * 8}px, 0)`;
        });
        hero?.addEventListener('pointerleave', () => {
            trophy.style.transform = '';
        });
    }
})();

/* =========================================================
   EXTRACURRICULAR interactions
   ========================================================= */
(function () {
    const page = document.querySelector('.ekskul-page');
    if (!page) return;

    const items = page.querySelectorAll('.ekskul-item');
    const steps = page.querySelectorAll('.ekskul-journey-step');
    const progress = page.querySelector('.ekskul-journey-progress');
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (!reduced && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12 });

        page.querySelectorAll('.reveal').forEach((element) => observer.observe(element));
    } else {
        page.querySelectorAll('.reveal').forEach((element) => element.classList.add('is-visible'));
    }

    items.forEach((item, index) => {
        item.style.transitionDelay = `${Math.min(index * 55, 330)}ms`;
    });

    function updateJourney() {
        if (!progress || !steps.length || reduced) return;
        const rect = progress.parentElement.getBoundingClientRect();
        const viewport = window.innerHeight;
        const start = viewport * 0.72;
        const end = -rect.height * 0.1;
        const value = Math.max(0, Math.min(1, (start - rect.top) / (start - end)));
        progress.style.width = `${value * 90}%`;

        steps.forEach((step, index) => {
            const stepRect = step.getBoundingClientRect();
            if (stepRect.top < viewport * 0.72 && stepRect.bottom > viewport * 0.2) {
                steps.forEach((other) => other.classList.remove('is-active'));
                step.classList.add('is-active');
            } else if (index === 0 && rect.top > viewport * 0.72) {
                step.classList.remove('is-active');
            }
        });
    }

    window.addEventListener('scroll', updateJourney, { passive: true });
    window.addEventListener('resize', updateJourney);
    updateJourney();

    const heroStage = page.querySelector('.ekskul-hero-stage');
    if (heroStage && !reduced && window.matchMedia('(pointer:fine)').matches) {
        heroStage.addEventListener('pointermove', (event) => {
            const rect = heroStage.getBoundingClientRect();
            const x = (event.clientX - rect.left) / rect.width - 0.5;
            const y = (event.clientY - rect.top) / rect.height - 0.5;
            heroStage.style.transform = `translate3d(${x * 8}px, ${y * 8}px, 0)`;
        });
        heroStage.addEventListener('pointerleave', () => {
            heroStage.style.transform = '';
        });
    }
})();
